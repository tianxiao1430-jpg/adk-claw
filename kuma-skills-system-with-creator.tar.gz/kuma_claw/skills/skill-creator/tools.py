"""
skill-creator - 工具定义
========================
创建和管理 kuma-claw skills 的工具集
"""

import json
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Optional
from google.adk.tools import FunctionTool


def init_skill(skill_name: str, skills_dir: str = "kuma_claw/skills") -> str:
    """初始化新 skill 的目录结构和文件

    Args:
        skill_name: Skill 名称（小写字母、数字、连字符）
        skills_dir: Skills 目录路径（默认 kuma_claw/skills）

    Returns:
        成功/失败消息
    """
    try:
        # 验证名称格式
        import re

        if not re.match(r"^[a-z0-9-]+$", skill_name):
            return f"❌ Skill 名称格式错误：只能包含小写字母、数字和连字符"

        if len(skill_name) > 64:
            return f"❌ Skill 名称过长：最多 64 字符"

        # 创建目录
        skills_path = Path(skills_dir)
        skill_dir = skills_path / skill_name

        if skill_dir.exists():
            return f"❌ Skill '{skill_name}' 已存在"

        skill_dir.mkdir(parents=True, exist_ok=True)

        # 创建 skill.json
        skill_json = {
            "name": skill_name,
            "version": "1.0.0",
            "description": f"{skill_name} skill for kuma-claw",
            "triggers": [skill_name],
            "author": "",
            "dependencies": [],
            "tools": [],
        }

        with open(skill_dir / "skill.json", "w", encoding="utf-8") as f:
            json.dump(skill_json, f, indent=2, ensure_ascii=False)

        # 创建 tools.py
        tools_py = f'''"""
{skill_name} - 工具定义
"""

from google.adk.tools import FunctionTool


def example_tool(param: str) -> str:
    """示例工具

    Args:
        param: 参数说明

    Returns:
        结果字符串
    """
    return f"收到: {{param}}"


TOOLS = [
    FunctionTool(func=example_tool)
]
'''

        with open(skill_dir / "tools.py", "w", encoding="utf-8") as f:
            f.write(tools_py)

        # 创建 prompts.py
        prompts_py = f'''"""
{skill_name} - 提示词定义
"""

SYSTEM_PROMPT = """
## {skill_name} 能力

TODO: 添加技能说明和使用场景

### 可用工具
- **example_tool**: 示例工具说明

### 使用示例
```python
example_tool(param="value")
```
"""

EXAMPLES = [
    {{
        "user": "示例用户输入",
        "assistant": "示例助手回复",
        "tool_call": "example_tool(param='value')"
    }}
]
'''

        with open(skill_dir / "prompts.py", "w", encoding="utf-8") as f:
            f.write(prompts_py)

        # 创建 __init__.py
        with open(skill_dir / "__init__.py", "w", encoding="utf-8") as f:
            f.write(
                f'"""{skill_name} skill"""\nfrom .tools import TOOLS\nfrom .prompts import SYSTEM_PROMPT, EXAMPLES\n'
            )

        return f"""✅ Skill '{skill_name}' 初始化成功

📁 位置: {skill_dir}

📝 已创建文件：
- skill.json    (元数据)
- tools.py      (工具定义)
- prompts.py    (提示词)
- __init__.py   (导出接口)

🎯 下一步：
1. 编辑 skill.json 添加触发词和工具定义
2. 实现 tools.py 中的工具函数
3. 完善 prompts.py 中的系统提示词
4. 使用 validate_skill() 验证结构
5. 使用 package_skill() 打包分发"""

    except Exception as e:
        return f"❌ 初始化失败: {str(e)}"


def validate_skill(skill_name: str, skills_dir: str = "kuma_claw/skills") -> str:
    """验证 skill 结构和配置是否正确

    Args:
        skill_name: 要验证的 skill 名称
        skills_dir: Skills 目录路径

    Returns:
        验证结果
    """
    try:
        skill_path = Path(skills_dir) / skill_name

        if not skill_path.exists():
            return f"❌ Skill '{skill_name}' 不存在"

        errors = []
        warnings = []

        # 检查必需文件
        required_files = ["skill.json", "tools.py", "prompts.py", "__init__.py"]
        for file in required_files:
            if not (skill_path / file).exists():
                errors.append(f"缺少必需文件: {file}")

        # 验证 skill.json
        try:
            with open(skill_path / "skill.json", "r", encoding="utf-8") as f:
                skill_json = json.load(f)

            # 检查必需字段
            required_fields = ["name", "version", "description", "triggers"]
            for field in required_fields:
                if field not in skill_json:
                    errors.append(f"skill.json 缺少必需字段: {field}")

            # 检查触发词
            if "triggers" in skill_json:
                if not isinstance(skill_json["triggers"], list) or len(skill_json["triggers"]) == 0:
                    errors.append("triggers 必须是非空数组")

            # 检查版本格式
            if "version" in skill_json:
                import re

                if not re.match(r"^\d+\.\d+\.\d+$", skill_json["version"]):
                    warnings.append(f"版本格式不符合 semver: {skill_json['version']}")

        except json.JSONDecodeError:
            errors.append("skill.json 格式错误")
        except Exception as e:
            errors.append(f"读取 skill.json 失败: {str(e)}")

        # 检查 tools.py
        try:
            tools_path = skill_path / "tools.py"
            with open(tools_path, "r", encoding="utf-8") as f:
                content = f.read()
                if "TOOLS" not in content:
                    warnings.append("tools.py 中未找到 TOOLS 列表")
                if "FunctionTool" not in content:
                    warnings.append("tools.py 中未使用 FunctionTool")
        except Exception as e:
            errors.append(f"读取 tools.py 失败: {str(e)}")

        # 检查 prompts.py
        try:
            prompts_path = skill_path / "prompts.py"
            with open(prompts_path, "r", encoding="utf-8") as f:
                content = f.read()
                if "SYSTEM_PROMPT" not in content:
                    warnings.append("prompts.py 中未找到 SYSTEM_PROMPT")
        except Exception as e:
            errors.append(f"读取 prompts.py 失败: {str(e)}")

        # 生成结果
        result_lines = [f"🔍 Skill '{skill_name}' 验证结果:\n"]

        if errors:
            result_lines.append("❌ 错误:")
            for error in errors:
                result_lines.append(f"  - {error}")

        if warnings:
            result_lines.append("\n⚠️  警告:")
            for warning in warnings:
                result_lines.append(f"  - {warning}")

        if not errors and not warnings:
            result_lines.append("✅ 所有检查通过！Skill 结构正确。")

        return "\n".join(result_lines)

    except Exception as e:
        return f"❌ 验证失败: {str(e)}"


def package_skill(skill_name: str, output_dir: str = ".", skills_dir: str = "kuma_claw/skills") -> str:
    """打包 skill 为 .skill 文件

    Args:
        skill_name: 要打包的 skill 名称
        output_dir: 输出目录（默认当前目录）
        skills_dir: Skills 目录路径

    Returns:
        打包结果
    """
    try:
        skill_path = Path(skills_dir) / skill_name

        if not skill_path.exists():
            return f"❌ Skill '{skill_name}' 不存在"

        # 先验证
        validation = validate_skill(skill_name, skills_dir)
        if "❌ 错误:" in validation:
            return f"❌ 验证失败，无法打包:\n{validation}"

        # 创建临时目录并复制文件
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_skill_dir = Path(tmpdir) / skill_name
            shutil.copytree(skill_path, tmp_skill_dir)

            # 创建 .skill 文件（实际上是 zip）
            output_path = Path(output_dir) / f"{skill_name}.skill"

            # 删除已存在的文件
            if output_path.exists():
                output_path.unlink()

            # 打包
            shutil.make_archive(str(output_path.with_suffix("")), "zip", tmpdir, skill_name)

            # 重命名为 .skill
            zip_path = output_path.with_suffix(".zip")
            zip_path.rename(output_path)

            # 获取文件大小
            size = output_path.stat().st_size
            size_str = f"{size / 1024:.1f}KB" if size > 1024 else f"{size}B"

            return f"""✅ Skill '{skill_name}' 打包成功

📦 文件: {output_path}
📊 大小: {size_str}

📋 包含内容:
- skill.json
- tools.py
- prompts.py
- __init__.py

🚀 可以分发此文件，其他人解压后即可使用"""

    except Exception as e:
        return f"❌ 打包失败: {str(e)}"


# 导出工具列表
TOOLS = [
    FunctionTool(func=init_skill),
    FunctionTool(func=validate_skill),
    FunctionTool(func=package_skill),
]
