"""
kuma_claw/skills/skill_manager.py
==================================
Skill 管理器 - 加载、注册、管理 skills
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
from google.adk.tools import FunctionTool

logger = logging.getLogger("kuma_claw")


class Skill:
    """Skill 定义"""

    def __init__(self, skill_dir: Path):
        self.dir = skill_dir
        self.metadata = self._load_metadata()
        self.tools = self._load_tools()
        self.prompts = self._load_prompts()

    def _load_metadata(self) -> dict:
        """加载 skill.json"""
        metadata_file = self.dir / "skill.json"
        if not metadata_file.exists():
            raise FileNotFoundError(f"skill.json not found in {self.dir}")

        with open(metadata_file) as f:
            return json.load(f)

    def _load_tools(self) -> List[FunctionTool]:
        """动态加载 tools.py"""
        try:
            import importlib.util

            spec = importlib.util.spec_from_file_location("tools", self.dir / "tools.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return getattr(module, "TOOLS", [])
        except Exception as e:
            logger.warning(f"Failed to load tools from {self.dir}: {e}")
            return []

    def _load_prompts(self) -> dict:
        """动态加载 prompts.py"""
        try:
            import importlib.util

            spec = importlib.util.spec_from_file_location("prompts", self.dir / "prompts.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return {
                "system": getattr(module, "SYSTEM_PROMPT", ""),
                "examples": getattr(module, "EXAMPLES", []),
            }
        except Exception as e:
            logger.warning(f"Failed to load prompts from {self.dir}: {e}")
            return {}

    @property
    def name(self) -> str:
        return self.metadata.get("name", self.dir.name)

    @property
    def triggers(self) -> List[str]:
        return self.metadata.get("triggers", [])


class SkillManager:
    """Skill 管理器"""

    def __init__(self, skills_dir: Optional[Path] = None):
        self.skills_dir = skills_dir or Path(__file__).parent
        self.skills: Dict[str, Skill] = {}
        self._load_all_skills()

    def _load_all_skills(self):
        """加载所有 skills"""
        if not self.skills_dir.exists():
            logger.warning(f"Skills directory not found: {self.skills_dir}")
            return

        for skill_dir in self.skills_dir.iterdir():
            if skill_dir.is_dir() and (skill_dir / "skill.json").exists():
                try:
                    skill = Skill(skill_dir)
                    self.skills[skill.name] = skill
                    logger.info(f"Loaded skill: {skill.name}")
                except Exception as e:
                    logger.error(f"Failed to load skill {skill_dir.name}: {e}")

    def get_skill_by_trigger(self, text: str) -> Optional[Skill]:
        """根据触发词查找 skill"""
        text_lower = text.lower()
        for skill in self.skills.values():
            for trigger in skill.triggers:
                if trigger.lower() in text_lower:
                    return skill
        return None

    def get_all_tools(self) -> List[FunctionTool]:
        """获取所有 skill 的工具"""
        tools = []
        for skill in self.skills.values():
            tools.extend(skill.tools)
        return tools

    def get_all_prompts(self) -> str:
        """获取所有 skill 的系统提示词"""
        prompts = []
        for skill in self.skills.values():
            if skill.prompts.get("system"):
                prompts.append(skill.prompts["system"])
        return "\n\n".join(prompts)

    def list_skills(self) -> List[dict]:
        """列出所有 skills"""
        return [
            {
                "name": skill.name,
                "description": skill.metadata.get("description", ""),
                "triggers": skill.triggers,
                "tools_count": len(skill.tools),
            }
            for skill in self.skills.values()
        ]

    def reload_skill(self, skill_name: str) -> bool:
        """重新加载指定 skill"""
        skill_dir = self.skills_dir / skill_name
        if not skill_dir.exists():
            logger.error(f"Skill directory not found: {skill_dir}")
            return False

        try:
            skill = Skill(skill_dir)
            self.skills[skill.name] = skill
            logger.info(f"Reloaded skill: {skill.name}")
            return True
        except Exception as e:
            logger.error(f"Failed to reload skill {skill_name}: {e}")
            return False


# 全局实例
skill_manager = SkillManager()
