# Kuma Claw Skills - 快速参考

## 🚀 一键开始

```bash
# 1. 安装
cp kuma-skills-system.skill kuma_claw/skills/ && cd kuma_claw/skills && unzip kuma-skills-system.skill

# 2. 集成（参考 INTEGRATION_GUIDE.md）

# 3. 测试
python3 test_skills.py
```

## 📦 Skill 结构

```
my-skill/
├── skill.json      # 元数据（触发词、依赖）
├── tools.py        # 工具实现（FunctionTool）
├── prompts.py      # 系统提示词
└── __init__.py     # 导出接口
```

## 🛠️ 常用命令

```bash
# 列出 skills
kuma-claw skills

# 查看详情
kuma-claw skill-info <name>

# 创建新 skill
python3 scripts/init_skill.py <name>

# 重新加载
kuma-claw skill-reload <name>
```

## 📝 skill.json 模板

```json
{
  "name": "my-skill",
  "version": "1.0.0",
  "description": "描述",
  "triggers": ["触发词1", "触发词2"],
  "dependencies": [],
  "tools": []
}
```

## 🔧 tools.py 模板

```python
from google.adk.tools import FunctionTool

def my_tool(param: str) -> str:
    """工具描述"""
    # 实现
    return "结果"

TOOLS = [FunctionTool(func=my_tool)]
```

## 💬 prompts.py 模板

```python
SYSTEM_PROMPT = """
## 我的能力
说明如何使用这个 skill...
"""

EXAMPLES = [
    {
        "user": "示例输入",
        "tool_call": "my_tool(param='value')"
    }
]
```

## 🎯 触发规则

- ✅ **匹配**: 触发词在用户消息中出现（不区分大小写）
- ✅ **示例**: "东京天气" → 匹配 ["天气", "weather"]
- ❌ **不匹配**: 触发词冲突时，先加载的 skill 优先

## 🐛 常见问题

### Skill 未加载
```bash
# 检查结构
ls -la kuma_claw/skills/my-skill/
# 必须有 skill.json
```

### 工具未调用
- 检查触发词是否匹配
- 检查工具描述是否清晰
- 查看日志: `kuma-claw logs --skills`

### 导入错误
```bash
# 安装依赖
pip install -r kuma_claw/skills/my-skill/requirements.txt
```

## 📚 文档导航

- **SKILL.md** - Skills 系统使用指南
- **SKILLS_README.md** - 完整文档和 API
- **INTEGRATION_GUIDE.md** - 集成步骤
- **skill_schema.md** - Schema 参考
- **SUMMARY.md** - 完成总结

## 🔗 API 快速参考

```python
from kuma_claw.skills import SkillManager

# 初始化
manager = SkillManager()

# 列出 skills
skills = manager.list_skills()

# 查找 skill
skill = manager.get_skill_by_trigger("天气")

# 获取工具
tools = manager.get_all_tools()

# 获取提示词
prompts = manager.get_all_prompts()
```

## 💡 最佳实践

### 工具设计
- ✅ 单一职责
- ✅ 清晰描述
- ✅ 类型提示
- ✅ 错误处理

### 提示词设计
- ✅ 具体示例
- ✅ 上下文说明
- ✅ 简洁明了

### 触发词设计
- ✅ 覆盖变体
- ✅ 避免重叠
- ✅ 测试覆盖

## 🎉 示例 Skills

### Weather
```bash
# 复制示例
cp -r references/example_weather_skill ../weather

# 测试
kuma-claw test "东京天气"
```

### 自定义
```bash
# 创建
python3 scripts/init_skill.py my-skill

# 编辑
# skill.json, tools.py, prompts.py

# 测试
kuma-claw skill-reload my-skill
```

---

**快速参考 v1.0** | 更多细节见完整文档
